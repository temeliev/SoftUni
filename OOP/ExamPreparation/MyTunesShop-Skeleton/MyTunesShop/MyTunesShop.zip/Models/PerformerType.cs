﻿namespace MyTunesShop.Models
{
    public enum PerformerType
    {
        Singer,
        Band
    }
}
