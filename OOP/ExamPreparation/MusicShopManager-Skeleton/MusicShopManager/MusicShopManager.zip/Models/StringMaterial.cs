﻿namespace MusicShop.Models
{
    public enum StringMaterialType
    {
        Steel,
        Brass,
        Bronze,
        Nylon
    }
}
